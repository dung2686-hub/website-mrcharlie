# 📅 HƯỚNG DẪN SỬ DỤNG NHANH
# LỊCH ÂM DƯƠNG SMART (Bản Mới Nhất)

---

## 🚀 1. Cài đặt & Khởi động

1.  **Cài đặt:** Chạy file `SetupLichAmDuong_v1.1.exe` -> Bấm Next liên tục -> Xong.
2.  **Khởi động:**
    *   Click icon **Lịch Âm Dương** ngoài Desktop.
    *   ⚡ **Lưu ý:** App sẽ hiện **Mini Widget** (lịch nhỏ) trước để bạn xem ngày ngay lập tức.
    *   Muốn mở lịch to? Bấm vào Widget hoặc icon ở góc màn hình.

---

## 🔥 2. Tính năng "Ăn tiền"

1.  **Spotlight (Lệnh giọng nói bằng tay):**
    *   Bấm **`Ctrl + K`**.
    *   Gõ tự nhiên: `họp sếp 9h sáng mai`, `sn vợ chủ nhật tới`.
    *   Enter cái là xong!

2.  **Mini Widget (Siêu nhẹ):**
    *   Luôn hiện ngày âm/dương góc màn hình.
    *   Tự động chạy cùng Windows (không làm chậm máy).

3.  **Tra cứu Phong thủy:**
    *   Xem ngày tốt/xấu, giờ hoàng đạo chuẩn xác.

---

## � Tài liệu đầy đủ
Để xem chi tiết cách đổi hình nền, nhập danh ngôn, sao lưu dữ liệu... vui lòng xem file:
� **[HUONG_DAN_CHI_TIET.md](HUONG_DAN_CHI_TIET.md)**

---
*Chúc bạn một ngày làm việc năng suất!* 🎉
