# HƯỚNG DẪN SỬ DỤNG CHI TIẾT
# LỊCH ÂM DƯƠNG SMART ASSISTANT 2.0

Chào mừng bạn đến với phiên bản Lịch Âm Dương mới nhất, được tối ưu hóa tốc độ và trải nghiệm người dùng.

---

## ⚡ 1. CƠ CHẾ KHỞI ĐỘNG THÔNG MINH (SMART STARTUP)

Khác với các bản cũ, phiên bản này sở hữu công nghệ **"Lazy Loading"**:
1.  **Khi bật máy:** Ứng dụng sẽ tự chạy dưới dạng **Mini Widget** (Lịch nhỏ xíu 70x70px) ở góc màn hình.
    *   *Lợi ích:* Khởi động tức thì, không làm đơ máy.
2.  **Khi cần dùng:** Bạn click vào Widget -> Giao diện chính (Dashboard) sẽ hiện lên ngay lập tức.

---

## 🔑 2. KÍCH HOẠT BẢN QUYỀN

*   Lần đầu mở App, hãy copy **Mã Máy (HWID)** và gửi cho quản trị viên để nhận Key.
*   Key được cấp phép theo từng máy tính để đảm bảo bảo mật.

---

## ⌨️ 3. PHÍM TẮT QUYỀN NĂNG (HOTKEYS)

Hãy dùng phím tắt để thao tác nhanh như Hacker:

| Phím Tắt | Chức Năng |
| :--- | :--- |
| **Ctrl + K** | **Spotlight:** Tìm kiếm / Tạo nhắc nhở nhanh |
| **Ctrl + W** | Bật/Tắt Widget Mini |
| **Ctrl + Q** | Thoát hoàn toàn ứng dụng |
| **Ctrl + 1/2/3/4** | Chuyển nhanh các Tab: Trang chủ / Lịch / Ghi chú / Nhắc nhở |

---

## 🔍 4. TÍNH NĂNG SPOTLIGHT (Ctrl + K)

Gõ lệnh tự nhiên thay vì bấm chuột:
*   **Đặt lịch hẹn:** Gõ `Họp team 2h chiều mai` -> App tự hiểu là 14:00 ngày mai.
*   **Ghi chú nhanh:** Gõ `gc Mua sữa cho con` -> Tự lưu vào ghi chú.
*   **Tìm kiếm:** Gõ `sếp`, `hợp đồng`... để tìm lại mọi dữ liệu cũ.

---

## 🛠️ 5. SAO LƯU & KHÔI PHỤC

Dữ liệu là tài sản quý giá nhất:
1.  Vào **Cài đặt** (Icon bánh răng).
2.  Mục **Sao lưu dữ liệu**:
    *   Bấm **Sao lưu ngay**: Để tạo file backup an toàn.
    *   App cũng tự động sao lưu mỗi khi bạn mở máy (giữ lại 7 bản gần nhất).

---

## ❓ CÂU HỎI THƯỜNG GẶP (FAQ)

**Q: Làm sao để app khởi động cùng Windows?**
A: Mặc định app đã tự kích hoạt tính năng này. Nếu muốn tắt, bạn vào Cài đặt -> Bỏ tích "Khởi động cùng Windows".

**Q: Tôi muốn đổi hình nền theo ý mình?**
A: Đơn giản! Vào Dashboard -> Chuột phải vào vùng trống -> Chọn "Đổi hình nền" hoặc kéo ảnh từ bên ngoài thả vào là xong.

**Q: App có chạy được khi không có mạng?**
A: Hoàn toàn được! App chạy Offline 100%, dữ liệu lưu trên máy bạn.

---
*Chúc bạn có trải nghiệm tuyệt vời!*
*Hỗ trợ kỹ thuật: 0988660809 (Zalo)*
